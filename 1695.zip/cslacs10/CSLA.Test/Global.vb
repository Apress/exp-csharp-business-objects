Module Global

  Public Session As New Hashtable()

End Module

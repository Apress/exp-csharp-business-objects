For the most recent code, including any updates, please refer to

http://www.lhotka.net/Articles.aspx?id=bd7a0904-e76d-48c3-a3ab-a8e9d9645c91


For details on setting up the ProjectTracker sample application plesae refer to

http://www.lhotka.net/Articles.aspx?id=99abd156-6309-43a7-b259-e92d1ec96992


For further information refer to the readme.txt files in the CSLA and ProjectTracker directories respectively.

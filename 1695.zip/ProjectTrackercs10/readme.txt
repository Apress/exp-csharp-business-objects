For information on installation, book errata, updates to the framework and so forth, 
please visit http://www.lhotka.net.


Specific instructions for configuring the ProjectTracker sample application can be found here:

http://www.lhotka.net/Articles.aspx?id=99abd156-6309-43a7-b259-e92d1ec96992
